﻿$("input[name='phone']").inputmask("+7 (999) 999 99 99");
$("input[name='card']").inputmask("701999999999");